const express = require('express')
const router = express.Router()
const { register, login, getProfile, logout } = require('../controllers/authController')
const { protect } = require('../middleware/auth')

// POST /register — create new account
router.post('/register', register)

// POST /login — authenticate user
router.post('/login', login)

// GET /profile — protected, requires valid JWT
router.get('/profile', protect, getProfile)

// POST /logout — clear token cookie
router.post('/logout', logout)

module.exports = router
