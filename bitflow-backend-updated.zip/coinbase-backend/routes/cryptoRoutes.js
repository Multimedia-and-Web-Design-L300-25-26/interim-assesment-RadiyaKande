const express = require('express')
const router = express.Router()
const {
  getAllCrypto,
  getTopGainers,
  getNewListings,
  addCrypto,
} = require('../controllers/cryptoController')

// GET /crypto — all tradable cryptocurrencies
router.get('/', getAllCrypto)

// GET /crypto/gainers — top gainers
router.get('/gainers', getTopGainers)

// GET /crypto/new — newest listings
router.get('/new', getNewListings)

// POST /crypto — add new cryptocurrency
router.post('/', addCrypto)

module.exports = router
