const jwt = require('jsonwebtoken')
const User = require('../models/User')

// Helper: generate JWT and set HTTP-only cookie
const sendTokenResponse = (user, statusCode, res) => {
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  })

  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days in ms
  }

  res.cookie('token', token, cookieOptions)

  return res.status(statusCode).json({
    success: true,
    token,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      createdAt: user.createdAt,
    },
  })
}

// POST /register
const register = async (req, res) => {
  try {
    const { name, email, password } = req.body

    // Validate fields
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide name, email, and password.',
      })
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email })
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email already exists.',
      })
    }

    // Create user
    const user = await User.create({ name, email, password })

    sendTokenResponse(user, 201, res)
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Server error during registration.',
    })
  }
}

// POST /login
const login = async (req, res) => {
  try {
    const { email, password } = req.body

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password.',
      })
    }

    // Find user and include password for comparison
    const user = await User.findOne({ email }).select('+password')
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      })
    }

    // Check password
    const isMatch = await user.comparePassword(password)
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.',
      })
    }

    sendTokenResponse(user, 200, res)
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Server error during login.',
    })
  }
}

// GET /profile  (protected)
const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
    return res.status(200).json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      },
    })
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Server error fetching profile.',
    })
  }
}

// POST /logout
const logout = async (req, res) => {
  res.cookie('token', '', { httpOnly: true, expires: new Date(0) })
  return res.status(200).json({ success: true, message: 'Logged out successfully.' })
}

module.exports = { register, login, getProfile, logout }
