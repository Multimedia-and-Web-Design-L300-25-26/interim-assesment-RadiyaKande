const Crypto = require('../models/Crypto')

// GET /crypto — all cryptocurrencies
const getAllCrypto = async (req, res) => {
  try {
    const cryptos = await Crypto.find().sort({ createdAt: -1 })
    return res.status(200).json({
      success: true,
      count: cryptos.length,
      data: cryptos,
    })
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message })
  }
}

// GET /crypto/gainers — top gainers (highest 24h change)
const getTopGainers = async (req, res) => {
  try {
    const gainers = await Crypto.find({ change24h: { $gt: 0 } })
      .sort({ change24h: -1 })
      .limit(10)
    return res.status(200).json({
      success: true,
      count: gainers.length,
      data: gainers,
    })
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message })
  }
}

// GET /crypto/new — newest listings
const getNewListings = async (req, res) => {
  try {
    const newListings = await Crypto.find().sort({ createdAt: -1 }).limit(10)
    return res.status(200).json({
      success: true,
      count: newListings.length,
      data: newListings,
    })
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message })
  }
}

// POST /crypto — add new cryptocurrency
const addCrypto = async (req, res) => {
  try {
    const { name, symbol, price, image, change24h, marketCap, volume24h } = req.body

    if (!name || !symbol || price === undefined || change24h === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Please provide name, symbol, price, and 24h change.',
      })
    }

    // Check for duplicate symbol
    const existing = await Crypto.findOne({ symbol: symbol.toUpperCase() })
    if (existing) {
      return res.status(400).json({
        success: false,
        message: `A cryptocurrency with symbol ${symbol.toUpperCase()} already exists.`,
      })
    }

    const crypto = await Crypto.create({
      name,
      symbol,
      price,
      image: image || '',
      change24h,
      marketCap: marketCap || 0,
      volume24h: volume24h || 0,
    })

    return res.status(201).json({
      success: true,
      message: 'Cryptocurrency added successfully.',
      data: crypto,
    })
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message })
  }
}

module.exports = { getAllCrypto, getTopGainers, getNewListings, addCrypto }
