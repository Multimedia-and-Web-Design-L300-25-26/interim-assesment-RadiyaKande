# BitFlow Clone — Backend API

Node.js + Express + MongoDB REST API for the BitFlow Clone project.

## Tech Stack
- **Node.js** + **Express** — server framework
- **MongoDB** + **Mongoose** — database & ODM
- **JWT** — authentication tokens
- **bcryptjs** — password hashing
- **cookie-parser** — HTTP-only cookie support

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment variables
```bash
cp .env.example .env
```
Edit `.env` and fill in:
- `MONGO_URI` — your MongoDB Atlas connection string
- `JWT_SECRET` — a long random secret string

### 3. Run the server
```bash
# Development (with auto-restart)
npm run dev

# Production
npm start
```

Server runs on **http://localhost:5000**

---

## API Endpoints

### Auth
| Method | Route       | Description              | Protected |
|--------|-------------|--------------------------|-----------|
| POST   | /register   | Create new account       | No        |
| POST   | /login      | Login, returns JWT cookie| No        |
| GET    | /profile    | Get user profile         | ✅ Yes    |
| POST   | /logout     | Clear token cookie       | No        |

### Crypto
| Method | Route            | Description              | Protected |
|--------|------------------|--------------------------|-----------|
| GET    | /crypto          | All cryptocurrencies     | No        |
| GET    | /crypto/gainers  | Top gainers (24h)        | No        |
| GET    | /crypto/new      | Newest listings          | No        |
| POST   | /crypto          | Add new cryptocurrency   | No        |

---

## Request & Response Examples

### POST /register
```json
// Request body
{ "name": "Ibrahim", "email": "ibrahim@email.com", "password": "secret123" }

// Response
{ "success": true, "token": "...", "user": { "id": "...", "name": "Ibrahim", "email": "..." } }
```

### POST /login
```json
// Request body
{ "email": "ibrahim@email.com", "password": "secret123" }

// Response
{ "success": true, "token": "...", "user": { ... } }
```

### POST /crypto
```json
// Request body
{ "name": "Bitcoin", "symbol": "BTC", "price": 62000, "image": "https://...", "change24h": 2.5 }

// Response
{ "success": true, "message": "Cryptocurrency added successfully.", "data": { ... } }
```

## Deployment (Render)
1. Push code to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your GitHub repo
4. Set environment variables in Render dashboard
5. Deploy — Render will auto-detect Node.js
